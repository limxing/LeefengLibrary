package com.limxing.library.SlidMenu;

/**
 * Created by limxing on 16/3/28.
 */
public interface MyGestureActionListener {
    void actionRight();
    void actionLeft();
}
