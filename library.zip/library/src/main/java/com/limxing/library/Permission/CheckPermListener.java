package com.limxing.library.Permission;

/**
 * Created by limxing on 16/8/6.
 */
public interface CheckPermListener {
    //权限通过后的回调方法
    void superPermission();
}
