package com.limxing.library.DragList;

import android.widget.ImageView;

/**
 * 用来记录拖动Item信息的实体类
 *
 * @author zihao
 *
 */
public class DragItemInfo {
	public Object obj;
	public ImageView dragImgView;
}