package com.limxing.publicc.alertview;

/**
 * Created by limxing on 16/5/24.
 */
public interface OnConfirmeListener {
    void result(String s);
}
